<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Header with Back Button -->
        <div class="bg-gray-50 py-6 px-4 mb-8 rounded-lg">
            <div class="flex flex-col space-y-2">
                <a href="<?php echo e(route('admin.activity-logs.index')); ?>" class="text-blue-600 hover:text-blue-800 flex items-center w-fit">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10 19l-7-7m0 0l7-7m-7 7h18" />
                    </svg>
                    Back to All Logs
                </a>
                <h1 class="text-3xl font-bold text-gray-900">Product #<?php echo e($productId); ?> Activity</h1>
                <p class="text-sm text-gray-600">Detailed view of user interactions with this product</p>
            </div>
        </div>

        <!-- Stats Cards -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            <!-- Total Activities Card -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 p-6">
                <p class="text-gray-700 text-sm font-medium mb-2">Total Activities</p>
                <p class="text-gray-900 text-2xl font-bold"><?php echo e($logs->total()); ?></p>
            </div>

            <!-- Activity Types Card -->
            <div class="bg-white rounded-xl shadow-md overflow-hidden border border-gray-100 p-6">
                <p class="text-gray-700 text-sm font-medium mb-4">Activity Breakdown</p>
                <div class="space-y-3">
                    <?php $__currentLoopData = $activityCounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex justify-between items-center">
                            <span class="text-sm font-medium text-gray-700"><?php echo e(ucfirst($activity['_id'] ?? 'Unknown')); ?></span>
                            <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800"><?php echo e($activity['count'] ?? 0); ?></span>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>
        </div>

        <!-- Activity Logs Table -->
        <div class="bg-white shadow-md rounded-xl overflow-hidden border border-gray-200 mb-8">
            <div class="p-6">
                <h2 class="text-xl font-semibold text-gray-900 mb-6">Activity History</h2>
                <div class="overflow-x-auto min-h-[340px] flex flex-col justify-between">
                    <table class="min-w-full">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DATE & TIME</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">PRODUCT ID</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">USER</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">IP ADDRESS</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">DEVICE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $rowCount = 0; ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $rowCount++; ?>
                                <tr class="<?php echo e($rowCount % 2 === 0 ? 'bg-gray-50' : 'bg-white'); ?>">
                                    <td class="py-4 px-2 text-sm text-gray-500">
                                        <?php echo e(\Carbon\Carbon::parse($log->created_at)->format('M d, Y H:i:s')); ?>

                                    </td>
                                    <td class="py-4 px-2 text-center">
                                        <?php if(!empty($log->product_id)): ?>
    <a href="<?php echo e(route('admin.activity-logs.product', $log->product_id)); ?>" class="text-sm font-medium text-blue-600 hover:text-blue-900">
        #<?php echo e($log->product_id); ?>

    </a>
<?php else: ?>
    <span class="text-gray-400">N/A</span>
<?php endif; ?>
                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-700">
                                        <?php if($log->user_id): ?>
                                            User #<?php echo e($log->user_id); ?>

                                        <?php else: ?>
                                            Guest
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-500">
                                        <?php echo e($log->ip); ?>

                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-500">
                                        <span class="truncate max-w-xs block" title="<?php echo e($log->user_agent); ?>">
                                            <?php echo e(\Illuminate\Support\Str::limit($log->user_agent, 30)); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php for($i = $rowCount; $i < 8; $i++): ?>
                                <tr class="<?php echo e(($i+1) % 2 === 0 ? 'bg-gray-50' : 'bg-white'); ?>">
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                <div class="mt-6">
                    <?php echo e($logs->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\backup\xaamp ht docs backup\ssp-sem2\resources\views/admin/activity_logs/product_details.blade.php ENDPATH**/ ?>