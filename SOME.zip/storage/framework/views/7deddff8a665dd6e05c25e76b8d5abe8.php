<?php $__env->startSection('content'); ?>
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Header -->
        <div class="mb-8">
            <h1 class="text-3xl font-bold text-gray-900">Product Activity Logs</h1>
            <p class="mt-2 text-sm text-gray-600">View and analyze user interactions with your products</p>
        </div>

        <!-- Activity Logs Table Section -->


        <!-- Recent Activity Logs -->
        <div class="bg-white shadow-md rounded-xl overflow-hidden border border-gray-200 mb-8">
            <div class="p-6">
                <h2 class="text-xl font-semibold text-gray-900 mb-6">Recent Activity Logs</h2>
                
                <div class="overflow-x-auto min-h-[400px] flex flex-col justify-between">
                    <table class="min-w-full">
                        <thead>
                            <tr class="bg-gray-50">
                                <th class="py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">DATE & TIME</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">ACTIVITY</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">USER</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">IP ADDRESS</th>
                                <th class="py-3 text-center text-xs font-medium text-gray-500 uppercase tracking-wider">DEVICE</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $rowCount = 0; ?>
                            <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $rowCount++; ?>
                                <tr class="<?php echo e($rowCount % 2 === 0 ? 'bg-gray-50' : 'bg-white'); ?>">
                                    <td class="py-4 px-2 text-sm text-gray-500">
                                        <?php echo e(\Carbon\Carbon::parse($log->created_at)->format('M d, Y H:i:s')); ?>

                                    </td>
                                    <td class="py-4 px-2 text-center">
                                        <?php switch($log->activity):
                                            case ('login'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">Login</span>
                                                <?php break; ?>
                                            <?php case ('logout'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">Logout</span>
                                                <?php break; ?>
                                            <?php case ('view'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-blue-100 text-blue-800">Product View</span>
                                                <?php break; ?>
                                            <?php case ('add_to_cart'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-yellow-100 text-yellow-800">Add to Cart</span>
                                                <?php break; ?>
                                            <?php case ('purchase'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-purple-100 text-purple-800">Purchase</span>
                                                <?php break; ?>
                                            <?php case ('page_visit'): ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">Page Visit</span>
                                                <?php break; ?>
                                            <?php default: ?>
                                                <span class="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800"><?php echo e(ucfirst($log->activity ?? 'Unknown')); ?></span>
                                        <?php endswitch; ?>
                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-700">
                                        <?php if($log->user_id): ?>
                                            User #<?php echo e($log->user_id); ?>

                                        <?php else: ?>
                                            Guest
                                        <?php endif; ?>
                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-500">
                                        <?php echo e($log->ip); ?>

                                    </td>
                                    <td class="py-4 px-2 text-center text-sm text-gray-500">
                                        <span class="truncate max-w-xs block" title="<?php echo e($log->user_agent); ?>">
                                            <?php echo e(\Illuminate\Support\Str::limit($log->user_agent, 30)); ?>

                                        </span>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php for($i = $rowCount; $i < 10; $i++): ?>
                                <tr class="<?php echo e(($i+1) % 2 === 0 ? 'bg-gray-50' : 'bg-white'); ?>">
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                    <td class="py-4 px-2">&nbsp;</td>
                                </tr>
                            <?php endfor; ?>
                        </tbody>
                    </table>
                </div>
                
                <div class="mt-6">
                    <?php echo e($logs->links()); ?>

                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\backup\xaamp ht docs backup\ssp-sem2\resources\views/admin/activity_logs/index.blade.php ENDPATH**/ ?>