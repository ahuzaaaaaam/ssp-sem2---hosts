<a href="/" class="flex items-center justify-center">
    <div class="bg-red-600 rounded-full p-3 shadow-lg">
        <svg xmlns="http://www.w3.org/2000/svg" class="size-16" viewBox="0 0 24 24" fill="none" stroke="white" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
            <path d="M12 2C6.5 2 2 6.5 2 12s4.5 10 10 10 10-4.5 10-10S17.5 2 12 2z"></path>
            <path d="M4.9 4.9l14.2 14.2"></path>
            <path d="M19.1 4.9L4.9 19.1"></path>
            <circle cx="8.5" cy="8.5" r="1"></circle>
            <circle cx="15.5" cy="8.5" r="1"></circle>
            <circle cx="12" cy="12" r="1"></circle>
            <circle cx="8.5" cy="15.5" r="1"></circle>
            <circle cx="15.5" cy="15.5" r="1"></circle>
        </svg>
    </div>
    <span class="ml-2 text-3xl font-bold text-red-600">PizzApp</span>
</a>
<?php /**PATH D:\backup\xaamp ht docs backup\ssp-sem2\resources\views/components/authentication-card-logo.blade.php ENDPATH**/ ?>