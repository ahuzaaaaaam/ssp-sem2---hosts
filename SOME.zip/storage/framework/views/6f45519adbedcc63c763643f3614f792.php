<div>
    
    <!--[if BLOCK]><![endif]--><?php if(auth()->check()): ?>
        
        <script>
            document.addEventListener('DOMContentLoaded', function() {
                // Dispatch the login event to the Livewire component
                Livewire.dispatch('user-logged-in');
            });
        </script>
    <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
    
    
    <div wire:init="logUserActivity"></div>
</div>
<?php /**PATH D:\backup\xaamp ht docs backup\ssp-sem2\resources\views/livewire/auth/login-logger.blade.php ENDPATH**/ ?>