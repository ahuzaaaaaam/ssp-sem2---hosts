<?php $__env->startSection('title', 'Home'); ?>

<?php $__env->startSection('content'); ?>
<!-- Activity Logger Component -->
<?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('activity-logger');

$__html = app('livewire')->mount($__name, $__params, 'lw-874946026-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

<div class="pt-8 pb-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <!-- Hero Section -->
        <style>
            .hero-image {
                width: 100%;
                height: 650px;
                object-fit: cover;
                object-position: center;
                filter: brightness(0.65);
            }
            .hero-text {
                text-shadow: 2px 2px 4px rgba(0,0,0,0.8);
            }
        </style>
        <div class="relative overflow-hidden mb-12 shadow-2xl -mx-4 sm:-mx-6 lg:-mx-8 -mt-8 rounded-xl">
            <img src="https://images.unsplash.com/photo-1513104890138-7c749659a591" alt="Pizza Hero" class="hero-image">
            <div class="absolute inset-0 z-20 flex flex-col justify-center items-center text-center p-4">
                <h1 class="text-4xl md:text-5xl font-bold text-white mb-4 hero-text">Delicious Pizza Delivered</h1>
                <p class="text-xl text-white mb-2 max-w-2xl hero-text">Order your favorite pizza online and skip the queue</p>
            </div>
        </div>

        <!-- Featured Pizzas Section -->
        <section class="py-0">
            <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
                <h2 class="text-3xl font-bold text-center mb-8">Featured Pizzas</h2>

                <!-- Admin features removed -->

                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 mx-auto max-w-6xl">
                    <?php $__empty_1 = true; $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="bg-white rounded-xl shadow-lg overflow-hidden w-full max-w-sm" data-card-id="<?php echo e($product->id); ?>">
                        <img src="<?php echo e($product->image_url); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-64 object-cover">
                        <div class="p-6">
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="text-xl font-bold"><?php echo e($product->name); ?></h3>
                                <span class="text-lg font-bold">$<?php echo e(number_format($product->price, 2)); ?></span>
                            </div>
                            <p class="text-gray-600 mb-4"><?php echo e($product->description); ?></p>
                            
                            <div class="flex items-center justify-between">
                                <?php if($product->veg === 'Yes'): ?>
                                <span class="px-3 py-1 bg-green-100 text-green-800 rounded-full text-xs font-semibold">Vegetarian</span>
                                <?php else: ?>
                                <span class="px-3 py-1 bg-red-100 text-red-800 rounded-full text-xs font-semibold">Non-Vegetarian</span>
                                <?php endif; ?>
                                
                                <form action="<?php echo e(route('products.addToCart', $product->id)); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="bg-red-600 text-white px-4 py-2 rounded-full hover:bg-red-700 text-sm">
                                        Add to Cart
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <p class="text-gray-600">No featured products available.</p>
                    <?php endif; ?>
                </div>
            </div>
        </section>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
<!-- Admin scripts removed -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\backup\xaamp ht docs backup\ssp-sem2\resources\views/home.blade.php ENDPATH**/ ?>