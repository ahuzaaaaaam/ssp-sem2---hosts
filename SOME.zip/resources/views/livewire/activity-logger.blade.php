<div>
    {{-- This is an invisible component that logs user activities --}}
    {{-- It doesn't render anything visible, it just logs activities --}}
</div>
